#include <R.h>
#include <Rdefines.h>
#include <Rinternals.h>
#include <stdlib.h> 
#include <stdio.h>

void myfinalizer(SEXP bs)
{
  printf("The finalizer is called:\n");
  printf("TYPEOF: %d\n", TYPEOF(bs));
  printf("bs address: %p\n", EXTPTR_PTR(bs));
  free(EXTPTR_PTR(bs));
}

SEXP main()
{
  size_t hdrsize = Rf_sizeofHeader();
  int *dp, i;
  void *bs;
  SEXP res;

  bs = malloc(hdrsize + 100 * sizeof(int));
  dp = (int *)(bs+hdrsize);
  printf("Malloc pointer: %p, size: %zu\n", bs, hdrsize+100*sizeof(int));
  if (bs == NULL)
    Rf_error("Malloc failed");

  for(i = 0; i < 100; i++)
    dp[i] = i;

  PROTECT(res = allocVectorInPlace(INTSXP, 100, dp, bs, &myfinalizer, NULL));
  printf("Data ptr:\t %p\n", dp);
  printf("Result ptr:\t %p\n", res);
  UNPROTECT(1);
  return res;
}

SEXP NA_values()
{
  printf("NA values:\nint:\t%d\ndbl:\t%f\n", NA_INTEGER, NA_REAL);
  return ScalarInteger(NA_INTEGER);
}
